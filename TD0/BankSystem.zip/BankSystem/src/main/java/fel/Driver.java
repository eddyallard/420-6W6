package fel;

import bll.models.entities.Address;
import bll.models.entities.Client;
import bll.models.entities.Manager;

import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;

public class Driver {
    public static void main(String[] args){
       App.run();
    }
}
